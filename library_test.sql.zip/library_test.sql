--
-- Database: `library_test`
--
CREATE DATABASE IF NOT EXISTS `library_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library_test`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `books_authors`
--

CREATE TABLE `books_authors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books_authors`
--

INSERT INTO `books_authors` (`id`, `book_id`, `author_id`) VALUES
(1, 63, 63),
(2, 137, 137),
(3, 148, 148),
(4, 159, 159),
(5, 170, 170),
(6, 181, 181),
(7, 192, 192),
(8, 203, 203),
(9, 214, 214),
(10, 225, 225),
(11, 236, 236),
(12, 247, 247),
(13, 259, 259),
(14, 271, 271),
(15, 283, 283),
(16, 295, 295),
(17, 307, 307),
(18, 309, 5),
(19, 309, 6),
(20, 319, 7),
(21, 320, 8),
(22, 320, 9),
(23, 330, 13),
(24, 331, 14),
(25, 331, 15),
(26, 341, 16),
(27, 342, 17),
(28, 342, 18),
(29, 352, 19),
(30, 353, 20),
(31, 353, 21),
(32, 354, 22),
(33, 364, 23),
(34, 365, 24),
(35, 365, 25),
(36, 366, 26),
(37, 376, 27),
(38, 377, 28),
(39, 377, 29),
(40, 378, 30),
(41, 388, 31),
(42, 389, 32),
(43, 389, 33),
(44, 390, 34),
(45, 391, 38),
(46, 392, 42),
(47, 393, 43),
(48, 394, 43),
(49, 395, 47),
(50, 396, 48),
(51, 397, 48),
(52, 398, 52),
(53, 399, 53),
(54, 400, 53),
(55, 410, 54),
(56, 411, 55),
(57, 411, 56),
(58, 412, 57),
(59, 413, 61),
(60, 414, 62),
(61, 415, 62),
(62, 417, 67),
(63, 418, 68),
(64, 419, 68),
(65, 421, 73),
(66, 422, 74),
(67, 423, 74),
(68, 434, 76),
(69, 435, 77),
(70, 435, 78),
(71, 436, 79),
(72, 437, 83),
(73, 438, 84),
(74, 439, 84),
(75, 450, 86),
(76, 451, 87),
(77, 451, 88),
(78, 452, 89),
(79, 453, 93),
(80, 454, 94),
(81, 455, 94),
(82, 466, 96),
(83, 467, 97),
(84, 467, 98),
(85, 468, 99),
(86, 469, 103),
(87, 470, 104),
(88, 471, 104),
(89, 482, 106),
(90, 483, 107),
(91, 483, 108),
(92, 484, 109),
(93, 485, 113),
(94, 486, 114),
(95, 487, 114),
(96, 498, 116),
(97, 499, 117),
(98, 499, 118),
(99, 500, 119),
(100, 501, 123),
(101, 502, 124),
(102, 503, 124),
(103, 514, 126),
(104, 515, 127),
(105, 515, 128),
(106, 516, 129),
(107, 517, 133),
(108, 518, 134),
(109, 519, 134),
(110, 530, 136),
(111, 531, 137),
(112, 531, 138),
(113, 532, 139),
(114, 533, 143),
(115, 534, 144),
(116, 535, 144),
(117, 546, 146),
(118, 547, 147),
(119, 547, 148),
(120, 548, 149),
(121, 549, 153),
(122, 550, 154),
(123, 551, 154),
(124, 562, 156),
(125, 563, 157),
(126, 563, 158),
(127, 564, 159),
(128, 565, 163),
(129, 566, 164),
(130, 567, 164),
(131, 578, 166),
(132, 579, 167),
(133, 579, 168),
(134, 580, 169),
(135, 581, 173),
(136, 582, 174),
(137, 583, 174),
(138, 594, 176),
(139, 595, 177),
(140, 595, 178),
(141, 596, 179),
(142, 597, 183),
(143, 598, 184),
(144, 599, 184),
(145, 610, 186),
(146, 611, 187),
(147, 611, 188),
(148, 612, 189),
(149, 613, 193),
(150, 614, 194),
(151, 615, 194),
(152, 626, 196),
(153, 627, 197),
(154, 627, 198),
(155, 628, 199),
(156, 629, 203),
(157, 630, 204),
(158, 631, 204),
(159, 642, 206),
(160, 643, 207),
(161, 643, 208),
(162, 644, 209),
(163, 645, 213),
(164, 646, 214),
(165, 647, 214),
(166, 658, 216),
(167, 659, 217),
(168, 659, 218),
(169, 660, 219),
(170, 670, 220),
(171, 671, 221),
(172, 671, 222),
(173, 672, 223),
(174, 682, 224),
(175, 683, 225),
(176, 683, 226),
(177, 684, 227),
(178, 694, 228),
(179, 695, 229),
(180, 695, 230),
(181, 696, 231),
(182, 706, 232),
(183, 707, 233),
(184, 707, 234),
(185, 708, 235),
(186, 718, 236),
(187, 719, 237),
(188, 719, 238),
(189, 720, 239),
(190, 722, 243),
(191, 723, 244),
(192, 724, 244),
(193, 735, 246),
(194, 736, 247),
(195, 736, 248),
(196, 737, 249),
(197, 738, 253),
(198, 739, 254),
(199, 740, 254),
(200, 751, 256),
(201, 752, 257),
(202, 752, 258),
(203, 753, 259),
(204, 754, 263),
(205, 755, 264),
(206, 756, 264),
(207, 767, 266),
(208, 768, 267),
(209, 768, 268),
(210, 769, 269),
(211, 770, 273),
(212, 771, 274),
(213, 772, 274),
(214, 783, 276),
(215, 784, 277),
(216, 784, 278),
(217, 785, 279),
(218, 786, 283),
(219, 787, 284),
(220, 788, 284),
(221, 799, 286),
(222, 800, 287),
(223, 800, 288),
(224, 801, 289),
(225, 803, 293),
(226, 804, 294),
(227, 805, 294),
(228, 816, 296),
(229, 817, 297),
(230, 817, 298),
(231, 818, 299),
(232, 820, 303),
(233, 821, 304),
(234, 822, 304),
(235, 824, 311),
(236, 825, 312),
(237, 826, 312),
(238, 837, 316),
(239, 838, 317),
(240, 838, 318),
(241, 839, 319),
(242, 841, 323),
(243, 842, 324),
(244, 843, 324),
(245, 854, 328),
(246, 855, 329),
(247, 855, 330),
(248, 856, 331),
(249, 860, 335),
(250, 861, 336),
(251, 862, 336),
(252, 873, 340),
(253, 874, 341),
(254, 874, 342),
(255, 875, 343),
(256, 887, 347),
(257, 888, 348),
(258, 889, 348),
(259, 900, 352),
(260, 901, 353),
(261, 901, 354),
(262, 902, 355),
(263, 907, 359),
(264, 908, 360),
(265, 909, 360),
(266, 920, 364),
(267, 921, 365),
(268, 921, 366),
(269, 922, 367),
(270, 926, 371),
(271, 927, 372),
(272, 928, 372),
(273, 939, 376),
(274, 940, 377),
(275, 940, 378),
(276, 941, 379);

-- --------------------------------------------------------

--
-- Table structure for table `checkouts`
--

CREATE TABLE `checkouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `copy_id` int(11) DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `checkouts`
--

INSERT INTO `checkouts` (`id`, `copy_id`, `patron_id`) VALUES
(1, 92, 49),
(2, 93, 57),
(3, 98, 82),
(4, 99, 83),
(5, 100, 83),
(6, 110, 91),
(7, 111, 92),
(8, 112, 92),
(9, 132, 108),
(10, 133, 109),
(11, 134, 109);

-- --------------------------------------------------------

--
-- Table structure for table `copies`
--

CREATE TABLE `copies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `checkout` tinyint(1) NOT NULL,
  `due_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `patrons`
--

CREATE TABLE `patrons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `books_authors`
--
ALTER TABLE `books_authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `checkouts`
--
ALTER TABLE `checkouts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `copies`
--
ALTER TABLE `copies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `patrons`
--
ALTER TABLE `patrons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=380;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=946;
--
-- AUTO_INCREMENT for table `books_authors`
--
ALTER TABLE `books_authors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=277;
--
-- AUTO_INCREMENT for table `checkouts`
--
ALTER TABLE `checkouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `copies`
--
ALTER TABLE `copies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;
--
-- AUTO_INCREMENT for table `patrons`
--
ALTER TABLE `patrons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
